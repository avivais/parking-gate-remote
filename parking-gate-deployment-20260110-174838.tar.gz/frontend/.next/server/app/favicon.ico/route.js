var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__e242b538._.js")
R.c("server/chunks/2b22e_frontend__next-internal_server_app_favicon_ico_route_actions_10053785.js")
R.m(41205)
module.exports=R.m(41205).exports
