module.exports=[91654,(e,o,d)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app_favicon_ico_route_actions_10053785.js.map