module.exports=[40662,(a,b,c)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app_login_page_actions_ef877399.js.map