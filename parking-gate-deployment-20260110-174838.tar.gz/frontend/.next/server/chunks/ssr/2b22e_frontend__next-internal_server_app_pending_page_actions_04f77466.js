module.exports=[24580,(a,b,c)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app_pending_page_actions_04f77466.js.map