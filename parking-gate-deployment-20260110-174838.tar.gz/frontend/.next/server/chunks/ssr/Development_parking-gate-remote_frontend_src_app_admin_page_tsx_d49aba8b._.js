module.exports=[44734,a=>{"use strict";var b=a.i(47314),c=a.i(43398);function d(){let a=(0,c.useRouter)();return(0,b.useEffect)(()=>{a.replace("/admin/users")},[a]),null}a.s(["default",()=>d])}];

//# sourceMappingURL=Development_parking-gate-remote_frontend_src_app_admin_page_tsx_d49aba8b._.js.map