module.exports=[59116,(a,b,c)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app_admin_terminal_page_actions_d62b326f.js.map