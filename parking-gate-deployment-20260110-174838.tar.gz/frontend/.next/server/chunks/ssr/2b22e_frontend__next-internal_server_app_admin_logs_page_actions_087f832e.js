module.exports=[51977,(a,b,c)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app_admin_logs_page_actions_087f832e.js.map