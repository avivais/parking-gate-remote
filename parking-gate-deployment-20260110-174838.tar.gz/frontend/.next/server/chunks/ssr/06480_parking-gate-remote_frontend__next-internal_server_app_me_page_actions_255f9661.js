module.exports=[99286,(a,b,c)=>{}];

//# sourceMappingURL=06480_parking-gate-remote_frontend__next-internal_server_app_me_page_actions_255f9661.js.map