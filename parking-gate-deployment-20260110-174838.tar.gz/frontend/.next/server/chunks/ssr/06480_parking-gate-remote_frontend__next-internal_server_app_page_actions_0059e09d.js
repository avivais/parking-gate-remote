module.exports=[84945,(a,b,c)=>{}];

//# sourceMappingURL=06480_parking-gate-remote_frontend__next-internal_server_app_page_actions_0059e09d.js.map