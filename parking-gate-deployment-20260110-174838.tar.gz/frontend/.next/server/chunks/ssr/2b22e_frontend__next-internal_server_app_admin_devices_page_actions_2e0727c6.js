module.exports=[86562,(a,b,c)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app_admin_devices_page_actions_2e0727c6.js.map