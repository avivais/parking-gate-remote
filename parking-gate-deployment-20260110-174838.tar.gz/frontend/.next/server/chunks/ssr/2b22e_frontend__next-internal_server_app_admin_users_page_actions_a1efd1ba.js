module.exports=[75722,(a,b,c)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app_admin_users_page_actions_a1efd1ba.js.map