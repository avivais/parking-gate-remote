module.exports=[96263,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},91966,a=>{"use strict";let b={src:a.i(96263).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Development_parking-gate-remote_frontend_src_app_1743ac09._.js.map