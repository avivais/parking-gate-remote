module.exports=[47972,a=>{"use strict";var b=a.i(45785);function c({children:a}){return(0,b.jsx)("div",{className:"min-h-screen",style:{backgroundColor:"var(--bg)"},children:(0,b.jsx)("div",{className:"pt-14",children:a})})}a.s(["default",()=>c])}];

//# sourceMappingURL=Development_parking-gate-remote_frontend_src_app_admin_layout_tsx_2774243d._.js.map