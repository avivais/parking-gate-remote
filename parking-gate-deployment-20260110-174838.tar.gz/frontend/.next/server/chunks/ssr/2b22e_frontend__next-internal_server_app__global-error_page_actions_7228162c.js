module.exports=[97912,(a,b,c)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app__global-error_page_actions_7228162c.js.map