module.exports=[95124,(a,b,c)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app__not-found_page_actions_f6780ae7.js.map