module.exports=[68001,(a,b,c)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app_register_page_actions_4ed2ad15.js.map