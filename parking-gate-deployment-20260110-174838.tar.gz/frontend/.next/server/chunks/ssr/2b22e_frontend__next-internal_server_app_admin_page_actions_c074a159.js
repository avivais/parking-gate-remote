module.exports=[82208,(a,b,c)=>{}];

//# sourceMappingURL=2b22e_frontend__next-internal_server_app_admin_page_actions_c074a159.js.map