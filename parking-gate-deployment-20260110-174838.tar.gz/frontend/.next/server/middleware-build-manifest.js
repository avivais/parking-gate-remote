globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0efc4c0c3d3b4ea3.js",
    "static/chunks/ca09f54940d082cf.js",
    "static/chunks/82fae00729e1c134.js",
    "static/chunks/c66f9080fe46fc9e.js",
    "static/chunks/13b9b5cbc689cb7d.js",
    "static/chunks/turbopack-68e878795a03eaff.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];