(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,69124,(e,t,r)=>{t.exports=e.r(33399)},73888,e=>{"use strict";let t,r;var a,s=e.i(26413);let o={data:""},i=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,n=/\/\*[^]*?\*\/|  +/g,l=/\n+/g,d=(e,t)=>{let r="",a="",s="";for(let o in e){let i=e[o];"@"==o[0]?"i"==o[1]?r=o+" "+i+";":a+="f"==o[1]?d(i,o):o+"{"+d(i,"k"==o[1]?"":t)+"}":"object"==typeof i?a+=d(i,t?t.replace(/([^,])+/g,e=>o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):o):null!=i&&(o=/^--/.test(o)?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=d.p?d.p(o,i):o+":"+i+";")}return r+(t&&s?t+"{"+s+"}":s)+a},c={},u=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+u(e[r]);return t}return e};function p(e){let t,r,a=this||{},s=e.call?e(a.p):e;return((e,t,r,a,s)=>{var o;let p=u(e),f=c[p]||(c[p]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(p));if(!c[f]){let t=p!==e?e:(e=>{let t,r,a=[{}];for(;t=i.exec(e.replace(n,""));)t[4]?a.shift():t[3]?(r=t[3].replace(l," ").trim(),a.unshift(a[0][r]=a[0][r]||{})):a[0][t[1]]=t[2].replace(l," ").trim();return a[0]})(e);c[f]=d(s?{["@keyframes "+f]:t}:t,r?"":"."+f)}let m=r&&c.g?c.g:null;return r&&(c.g=c[f]),o=c[f],m?t.data=t.data.replace(m,o):-1===t.data.indexOf(o)&&(t.data=a?o+t.data:t.data+o),f})(s.unshift?s.raw?(t=[].slice.call(arguments,1),r=a.p,s.reduce((e,a,s)=>{let o=t[s];if(o&&o.call){let e=o(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;o=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+a+(null==o?"":o)},"")):s.reduce((e,t)=>Object.assign(e,t&&t.call?t(a.p):t),{}):s,(e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||o})(a.target),a.g,a.o,a.k)}p.bind({g:1});let f,m,h,g=p.bind({k:1});function x(e,t){let r=this||{};return function(){let a=arguments;function s(o,i){let n=Object.assign({},o),l=n.className||s.className;r.p=Object.assign({theme:m&&m()},n),r.o=/ *go\d+/.test(l),n.className=p.apply(r,a)+(l?" "+l:""),t&&(n.ref=i);let d=e;return e[0]&&(d=n.as||e,delete n.as),h&&d[0]&&h(n),f(d,n)}return t?t(s):s}}var b=(e,t)=>"function"==typeof e?e(t):e,y=(t=0,()=>(++t).toString()),v=()=>{if(void 0===r&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");r=!e||e.matches}return r},w="default",k=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return k(e,{type:+!!e.toasts.find(e=>e.id===a.id),toast:a});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let o=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+o}))}}},j=[],E={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},A={},T=(e,t=w)=>{A[t]=k(A[t]||E,e),j.forEach(([e,r])=>{e===t&&r(A[t])})},N=e=>Object.keys(A).forEach(t=>T(e,t)),C=(e=w)=>t=>{T(t,e)},S={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},I=(e={},t=w)=>{let[r,a]=(0,s.useState)(A[t]||E),o=(0,s.useRef)(A[t]);(0,s.useEffect)(()=>(o.current!==A[t]&&a(A[t]),j.push([t,a]),()=>{let e=j.findIndex(([e])=>e===t);e>-1&&j.splice(e,1)}),[t]);let i=r.toasts.map(t=>{var r,a,s;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||S[t.type],style:{...e.style,...null==(s=e[t.type])?void 0:s.style,...t.style}}});return{...r,toasts:i}},R=e=>(t,r)=>{let a,s=((e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||y()}))(t,e,r);return C(s.toasterId||(a=s.id,Object.keys(A).find(e=>A[e].toasts.some(e=>e.id===a))))({type:2,toast:s}),s.id},L=(e,t)=>R("blank")(e,t);L.error=R("error"),L.success=R("success"),L.loading=R("loading"),L.custom=R("custom"),L.dismiss=(e,t)=>{let r={type:3,toastId:e};t?C(t)(r):N(r)},L.dismissAll=e=>L.dismiss(void 0,e),L.remove=(e,t)=>{let r={type:4,toastId:e};t?C(t)(r):N(r)},L.removeAll=e=>L.remove(void 0,e),L.promise=(e,t,r)=>{let a=L.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?b(t.success,e):void 0;return s?L.success(s,{id:a,...r,...null==r?void 0:r.success}):L.dismiss(a),e}).catch(e=>{let s=t.error?b(t.error,e):void 0;s?L.error(s,{id:a,...r,...null==r?void 0:r.error}):L.dismiss(a)}),e};var O=1e3,P=(e,t="default")=>{let{toasts:r,pausedAt:a}=I(e,t),o=(0,s.useRef)(new Map).current,i=(0,s.useCallback)((e,t=O)=>{if(o.has(e))return;let r=setTimeout(()=>{o.delete(e),n({type:4,toastId:e})},t);o.set(e,r)},[]);(0,s.useEffect)(()=>{if(a)return;let e=Date.now(),s=r.map(r=>{if(r.duration===1/0)return;let a=(r.duration||0)+r.pauseDuration-(e-r.createdAt);if(a<0){r.visible&&L.dismiss(r.id);return}return setTimeout(()=>L.dismiss(r.id,t),a)});return()=>{s.forEach(e=>e&&clearTimeout(e))}},[r,a,t]);let n=(0,s.useCallback)(C(t),[t]),l=(0,s.useCallback)(()=>{n({type:5,time:Date.now()})},[n]),d=(0,s.useCallback)((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),c=(0,s.useCallback)(()=>{a&&n({type:6,time:Date.now()})},[a,n]),u=(0,s.useCallback)((e,t)=>{let{reverseOrder:a=!1,gutter:s=8,defaultPosition:o}=t||{},i=r.filter(t=>(t.position||o)===(e.position||o)&&t.height),n=i.findIndex(t=>t.id===e.id),l=i.filter((e,t)=>t<n&&e.visible).length;return i.filter(e=>e.visible).slice(...a?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+s,0)},[r]);return(0,s.useEffect)(()=>{r.forEach(e=>{if(e.dismissed)i(e.id,e.removeDelay);else{let t=o.get(e.id);t&&(clearTimeout(t),o.delete(e.id))}})},[r,i]),{toasts:r,handlers:{updateHeight:d,startPause:l,endPause:c,calculateOffset:u}}},U=g`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,$=g`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,D=g`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,_=x("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${U} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${$} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${D} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,z=g`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,H=x("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${z} 1s linear infinite;
`,M=g`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,F=g`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,B=x("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${M} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${F} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,q=x("div")`
  position: absolute;
`,W=x("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,V=g`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,X=x("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${V} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Z=({toast:e})=>{let{icon:t,type:r,iconTheme:a}=e;return void 0!==t?"string"==typeof t?s.createElement(X,null,t):t:"blank"===r?null:s.createElement(W,null,s.createElement(H,{...a}),"loading"!==r&&s.createElement(q,null,"error"===r?s.createElement(_,{...a}):s.createElement(B,{...a})))},G=x("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,J=x("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,K=s.memo(({toast:e,position:t,style:r,children:a})=>{let o=e.height?((e,t)=>{let r=e.includes("top")?1:-1,[a,s]=v()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*r}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*r}%,-1px) scale(.6); opacity:0;}
`];return{animation:t?`${g(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${g(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},i=s.createElement(Z,{toast:e}),n=s.createElement(J,{...e.ariaProps},b(e.message,e));return s.createElement(G,{className:e.className,style:{...o,...r,...e.style}},"function"==typeof a?a({icon:i,message:n}):s.createElement(s.Fragment,null,i,n))});a=s.createElement,d.p=void 0,f=a,m=void 0,h=void 0;var Y=({id:e,className:t,style:r,onHeightUpdate:a,children:o})=>{let i=s.useCallback(t=>{if(t){let r=()=>{a(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,a]);return s.createElement("div",{ref:i,className:t,style:r},o)},Q=p`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ee=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:a,children:o,toasterId:i,containerStyle:n,containerClassName:l})=>{let{toasts:d,handlers:c}=P(r,i);return s.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:l,onMouseEnter:c.startPause,onMouseLeave:c.endPause},d.map(r=>{let i,n,l=r.position||t,d=c.calculateOffset(r,{reverseOrder:e,gutter:a,defaultPosition:t}),u=(i=l.includes("top"),n=l.includes("center")?{justifyContent:"center"}:l.includes("right")?{justifyContent:"flex-end"}:{},{left:0,right:0,display:"flex",position:"absolute",transition:v()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${d*(i?1:-1)}px)`,...i?{top:0}:{bottom:0},...n});return s.createElement(Y,{id:r.id,key:r.id,onHeightUpdate:c.updateHeight,className:r.visible?Q:"",style:u},"custom"===r.type?b(r.message,r):o?o(r):s.createElement(K,{toast:r,position:l}))}))};e.s(["CheckmarkIcon",()=>B,"ErrorIcon",()=>_,"LoaderIcon",()=>H,"ToastBar",()=>K,"ToastIcon",()=>Z,"Toaster",()=>ee,"default",()=>L,"resolveValue",()=>b,"toast",()=>L,"useToaster",()=>P,"useToasterStore",()=>I],73888)},56829,e=>{"use strict";let t="https://api.mitzpe6-8.com/api",r="AUTH_UNAUTHORIZED",a=null,s=null;class o extends Error{status;data;constructor(e,t,r){super(e),this.name="ApiError",this.status=t,this.data=r}}function i(e){a=e}function n(){return a}function l(){a=null}async function d(){return s||(s=(async()=>{try{return a=(await u("/auth/refresh",{method:"POST",auth:!1,isRefreshCall:!0})).tokens.accessToken}catch(e){return a=null,null}finally{s=null}})())}async function c(){let e=await u("/auth/refresh",{method:"POST",auth:!1,isRefreshCall:!0});return a=e.tokens.accessToken,e}async function u(e,{method:s="GET",body:i,headers:n={},auth:l=!0,isRefreshCall:c=!1}={}){let p,f,m=e.startsWith("http")?e:`${t}${e.startsWith("/")?e:`/${e}`}`,h="/gate/open"===e&&"POST"===s;if(h){let e=n?.["X-Request-Id"]||n?.["x-request-id"];p=e||crypto.randomUUID()}let g={Accept:"application/json",...n};h&&p&&(g["X-Request-Id"]=p),void 0!==i&&(g["Content-Type"]="application/json"),l&&a&&(g.Authorization=`Bearer ${a}`);try{f=await fetch(m,{method:s,headers:g,body:void 0!==i?JSON.stringify(i):void 0,credentials:"include"})}catch(e){throw new o("שגיאת רשת, נסו שוב.",void 0,e)}if(401===f.status&&l&&!c){let e=await d();if(e){g.Authorization=`Bearer ${e}`,h&&p&&(g["X-Request-Id"]=p);try{f=await fetch(m,{method:s,headers:g,body:void 0!==i?JSON.stringify(i):void 0,credentials:"include"})}catch(e){throw new o("שגיאת רשת, נסו שוב.",void 0,e)}}}let x=f.headers.get("content-type")?.includes("application/json")?await f.json():null;if(!f.ok){let e="שגיאת שרת";if(x&&"object"==typeof x&&(Array.isArray(x.message)?e=x.message.join(", "):"message"in x&&"string"==typeof x.message&&(e=x.message)),e&&"שגיאת שרת"!==e||(e=f.statusText||"שגיאת שרת"),401===f.status)throw new o(r,401,x);if(403===f.status)throw new o(e,403,x);throw new o(e,f.status,x)}return x}e.s(["API_BASE_URL",0,t,"AUTH_FORBIDDEN",0,"AUTH_FORBIDDEN","AUTH_UNAUTHORIZED",0,r,"ApiError",()=>o,"apiRequest",()=>u,"clearAccessToken",()=>l,"getAccessToken",()=>n,"refreshToken",()=>c,"setAccessToken",()=>i])},76722,e=>{"use strict";let t;var r=e.i(1989),a=e.i(26413),s=e.i(69124),o=e.i(56829);let i="undefined"!=typeof crypto&&crypto.randomUUID&&crypto.randomUUID.bind(crypto),n=new Uint8Array(16),l=[];for(let e=0;e<256;++e)l.push((e+256).toString(16).slice(1));let d=function(e,r,a){if(i&&!r&&!e)return i();let s=(e=e||{}).random??e.rng?.()??function(){if(!t){if("undefined"==typeof crypto||!crypto.getRandomValues)throw Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");t=crypto.getRandomValues.bind(crypto)}return t(n)}();if(s.length<16)throw Error("Random bytes length must be >= 16");if(s[6]=15&s[6]|64,s[8]=63&s[8]|128,r){if((a=a||0)<0||a+16>r.length)throw RangeError(`UUID byte range ${a}:${a+15} is out of buffer bounds`);for(let e=0;e<16;++e)r[a+e]=s[e];return r}return function(e,t=0){return(l[e[t+0]]+l[e[t+1]]+l[e[t+2]]+l[e[t+3]]+"-"+l[e[t+4]]+l[e[t+5]]+"-"+l[e[t+6]]+l[e[t+7]]+"-"+l[e[t+8]]+l[e[t+9]]+"-"+l[e[t+10]]+l[e[t+11]]+l[e[t+12]]+l[e[t+13]]+l[e[t+14]]+l[e[t+15]]).toLowerCase()}(s)},c="pgr_device_id",u=(0,a.createContext)(void 0);function p({children:e}){let[t,i]=(0,a.useState)(null),[n,l]=(0,a.useState)(null),[p,f]=(0,a.useState)(!0),[m,h]=(0,a.useState)(!1),g=(0,s.useRouter)(),x=async()=>{try{await (0,o.refreshToken)();let e=await (0,o.apiRequest)("/auth/me");i(e.user),l(e.token)}catch(e){e instanceof o.ApiError&&(e.message,o.AUTH_UNAUTHORIZED),(0,o.clearAccessToken)(),i(null),l(null)}finally{h(!0),f(!1)}},b=async(e,t)=>{let r,a=((r=localStorage.getItem(c))||(r=d(),localStorage.setItem(c,r)),r),s=await (0,o.apiRequest)("/auth/login",{method:"POST",body:{email:e,password:t,deviceId:a},auth:!1});(0,o.setAccessToken)(s.tokens.accessToken),i(s.user);try{let e=await (0,o.apiRequest)("/auth/me");l(e.token)}catch(e){}f(!1),g.replace("/")},y=async(e,t,r,a,s,i,n)=>{await (0,o.apiRequest)("/auth/register",{method:"POST",body:{email:e,password:t,firstName:r,lastName:a,phone:s,apartmentNumber:i,floor:n},auth:!1})},v=async()=>{try{await (0,o.apiRequest)("/auth/logout",{method:"POST"})}catch(e){}finally{(0,o.clearAccessToken)(),i(null),l(null),g.push("/login")}},w=async e=>{i(await (0,o.apiRequest)("/auth/users/me",{method:"PATCH",body:e}))};return(0,a.useEffect)(()=>{x()},[]),(0,r.jsx)(u.Provider,{value:{user:t,token:n,loading:p,isReady:m,login:b,register:y,logout:v,refresh:x,updateUser:w},children:e})}function f(){let e=(0,a.useContext)(u);if(void 0===e)throw Error("useAuth must be used within an AuthProvider");return e}e.s(["AuthProvider",()=>p,"useAuth",()=>f],76722)},68988,e=>{e.v({name:"frontend",version:"0.1.6",private:!0,scripts:{dev:"next dev",build:"next build",start:"next start",lint:"eslint"},dependencies:{"@xterm/addon-fit":"^0.11.0","@xterm/addon-web-links":"^0.12.0","@xterm/xterm":"^5.5.0","framer-motion":"^11.18.2",next:"^16.0.10",react:"19.2.0","react-dom":"19.2.0","react-hot-toast":"^2.4.1","socket.io-client":"^4.8.1",uuid:"^11.1.0"},devDependencies:{"@tailwindcss/postcss":"^4","@types/node":"^20","@types/react":"^19","@types/react-dom":"^19","@types/uuid":"^10.0.0",eslint:"^9","eslint-config-next":"16.0.7",tailwindcss:"^4",typescript:"^5"}})},95766,30533,e=>{"use strict";var t=e.i(1989),r=e.i(26413);let a={luxury:{labelHe:"יוקרתי",tokens:{light:{bg:"#fafafa",surface:"#ffffff","surface-2":"#f5f5f5",text:"#1d1d1f",muted:"#86868b",primary:"#007aff","primary-hover":"#0051d5","primary-contrast":"#ffffff",success:"#34c759",danger:"#ff3b30",warning:"#ff9500",border:"#d2d2d7","border-strong":"#a1a1a6","shadow-sm":"0 1px 3px rgba(0, 0, 0, 0.08)","shadow-md":"0 4px 12px rgba(0, 0, 0, 0.1)","shadow-lg":"0 8px 24px rgba(0, 0, 0, 0.12)","radius-sm":"12px","radius-md":"16px","radius-lg":"24px","space-1":"4px","space-2":"8px","space-3":"12px","space-4":"16px","space-5":"24px","space-6":"32px","space-7":"40px","space-8":"48px","font-sans":'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',"font-weight-normal":"400","font-weight-semibold":"600","font-weight-bold":"700","letter-spacing-tight":"-0.01em","letter-spacing-normal":"0","letter-spacing-wide":"0.02em","headline-weight":"700","headline-size":"2.25rem","button-style":"filled","button-padding-x":"16px","button-padding-y":"12px","table-header-bg":"#f5f5f5","table-header-text":"#1d1d1f","table-row-hover":"#fafafa","table-border":"#d2d2d7","focus-ring":"#007aff"},dark:{bg:"#000000",surface:"#1c1c1e","surface-2":"#2c2c2e",text:"#f5f5f7",muted:"#98989d",primary:"#0a84ff","primary-hover":"#409cff","primary-contrast":"#ffffff",success:"#30d158",danger:"#ff453a",warning:"#ff9f0a",border:"#38383a","border-strong":"#48484a","shadow-sm":"0 1px 3px rgba(0, 0, 0, 0.3)","shadow-md":"0 4px 12px rgba(0, 0, 0, 0.4)","shadow-lg":"0 8px 24px rgba(0, 0, 0, 0.5)","radius-sm":"12px","radius-md":"16px","radius-lg":"24px","space-1":"4px","space-2":"8px","space-3":"12px","space-4":"16px","space-5":"24px","space-6":"32px","space-7":"40px","space-8":"48px","font-sans":'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',"font-weight-normal":"400","font-weight-semibold":"600","font-weight-bold":"700","letter-spacing-tight":"-0.01em","letter-spacing-normal":"0","letter-spacing-wide":"0.02em","headline-weight":"700","headline-size":"2.25rem","button-style":"filled","button-padding-x":"16px","button-padding-y":"12px","table-header-bg":"#2c2c2e","table-header-text":"#f5f5f7","table-row-hover":"#1c1c1e","table-border":"#38383a","focus-ring":"#0a84ff"}}},clean:{labelHe:"נקי",tokens:{light:{bg:"#fafafa",surface:"#ffffff","surface-2":"#f5f5f5",text:"#212121",muted:"#757575",primary:"#1976d2","primary-hover":"#1565c0","primary-contrast":"#ffffff",success:"#388e3c",danger:"#d32f2f",warning:"#f57c00",border:"#e0e0e0","border-strong":"#bdbdbd","shadow-sm":"0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)","shadow-md":"0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23)","shadow-lg":"0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23)","radius-sm":"4px","radius-md":"8px","radius-lg":"12px","space-1":"4px","space-2":"8px","space-3":"12px","space-4":"16px","space-5":"24px","space-6":"32px","space-7":"40px","space-8":"48px","font-sans":'"Roboto", "Helvetica", "Arial", sans-serif',"font-weight-normal":"400","font-weight-semibold":"500","font-weight-bold":"700","letter-spacing-tight":"-0.005em","letter-spacing-normal":"0","letter-spacing-wide":"0.01em","headline-weight":"500","headline-size":"2rem","button-style":"filled","button-padding-x":"16px","button-padding-y":"10px","table-header-bg":"#f5f5f5","table-header-text":"#212121","table-row-hover":"#fafafa","table-border":"#e0e0e0","focus-ring":"#1976d2"},dark:{bg:"#121212",surface:"#1e1e1e","surface-2":"#2c2c2c",text:"#ffffff",muted:"#b0b0b0",primary:"#90caf9","primary-hover":"#64b5f6","primary-contrast":"#000000",success:"#66bb6a",danger:"#ef5350",warning:"#ffa726",border:"#424242","border-strong":"#616161","shadow-sm":"0 1px 3px rgba(0, 0, 0, 0.5)","shadow-md":"0 3px 6px rgba(0, 0, 0, 0.6)","shadow-lg":"0 10px 20px rgba(0, 0, 0, 0.7)","radius-sm":"4px","radius-md":"8px","radius-lg":"12px","space-1":"4px","space-2":"8px","space-3":"12px","space-4":"16px","space-5":"24px","space-6":"32px","space-7":"40px","space-8":"48px","font-sans":'"Roboto", "Helvetica", "Arial", sans-serif',"font-weight-normal":"400","font-weight-semibold":"500","font-weight-bold":"700","letter-spacing-tight":"-0.005em","letter-spacing-normal":"0","letter-spacing-wide":"0.01em","headline-weight":"500","headline-size":"2rem","button-style":"filled","button-padding-x":"16px","button-padding-y":"10px","table-header-bg":"#2c2c2c","table-header-text":"#ffffff","table-row-hover":"#1e1e1e","table-border":"#424242","focus-ring":"#90caf9"}}},pro:{labelHe:"מקצועי",tokens:{light:{bg:"#f6f9fc",surface:"#ffffff","surface-2":"#f8fafc",text:"#0a2540",muted:"#6b7c93",primary:"#635bff","primary-hover":"#5851e6","primary-contrast":"#ffffff",success:"#00d97e",danger:"#df1c41",warning:"#ffb020",border:"#e3e8ef","border-strong":"#cbd5e0","shadow-sm":"0 1px 2px rgba(0, 0, 0, 0.05)","shadow-md":"0 4px 6px rgba(0, 0, 0, 0.07), 0 1px 3px rgba(0, 0, 0, 0.06)","shadow-lg":"0 10px 15px rgba(0, 0, 0, 0.1), 0 4px 6px rgba(0, 0, 0, 0.05)","radius-sm":"6px","radius-md":"10px","radius-lg":"16px","space-1":"4px","space-2":"8px","space-3":"12px","space-4":"16px","space-5":"20px","space-6":"24px","space-7":"32px","space-8":"40px","font-sans":'-apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif',"font-weight-normal":"400","font-weight-semibold":"600","font-weight-bold":"700","letter-spacing-tight":"-0.02em","letter-spacing-normal":"0","letter-spacing-wide":"0.01em","headline-weight":"600","headline-size":"1.875rem","button-style":"filled","button-padding-x":"14px","button-padding-y":"8px","table-header-bg":"#f8fafc","table-header-text":"#0a2540","table-row-hover":"#f6f9fc","table-border":"#e3e8ef","focus-ring":"#635bff"},dark:{bg:"#0a2540",surface:"#1a365d","surface-2":"#2d3748",text:"#f7fafc",muted:"#a0aec0",primary:"#7c3aed","primary-hover":"#6d28d9","primary-contrast":"#ffffff",success:"#10b981",danger:"#ef4444",warning:"#f59e0b",border:"#2d3748","border-strong":"#4a5568","shadow-sm":"0 1px 2px rgba(0, 0, 0, 0.3)","shadow-md":"0 4px 6px rgba(0, 0, 0, 0.4), 0 1px 3px rgba(0, 0, 0, 0.3)","shadow-lg":"0 10px 15px rgba(0, 0, 0, 0.5), 0 4px 6px rgba(0, 0, 0, 0.4)","radius-sm":"6px","radius-md":"10px","radius-lg":"16px","space-1":"4px","space-2":"8px","space-3":"12px","space-4":"16px","space-5":"20px","space-6":"24px","space-7":"32px","space-8":"40px","font-sans":'-apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif',"font-weight-normal":"400","font-weight-semibold":"600","font-weight-bold":"700","letter-spacing-tight":"-0.02em","letter-spacing-normal":"0","letter-spacing-wide":"0.01em","headline-weight":"600","headline-size":"1.875rem","button-style":"filled","button-padding-x":"14px","button-padding-y":"8px","table-header-bg":"#2d3748","table-header-text":"#f7fafc","table-row-hover":"#1a365d","table-border":"#2d3748","focus-ring":"#7c3aed"}}}},s="luxury",o="light";e.s(["DEFAULT_MODE",0,o,"DEFAULT_THEME",0,s,"THEMES",0,a],30533);let i=(0,r.createContext)(void 0);function n({children:e}){let[n,l]=(0,r.useState)(s),[d,c]=(0,r.useState)(o),[u,p]=(0,r.useState)(!1);(0,r.useEffect)(()=>{let e=localStorage.getItem("pgr_theme_id"),t=localStorage.getItem("pgr_theme_mode");e&&a[e]&&l(e),("light"===t||"dark"===t)&&c(t),p(!0)},[]),(0,r.useEffect)(()=>{if(!u)return;let e=document.documentElement,t=a[n].tokens[d];e.setAttribute("data-theme",n),e.setAttribute("data-mode",d),Object.entries(t).forEach(([t,r])=>{e.style.setProperty(`--${t}`,r)})},[n,d,u]);let f=e=>{c(e),localStorage.setItem("pgr_theme_mode",e)};return(0,t.jsx)(i.Provider,{value:{themeId:n,mode:d,setTheme:e=>{l(e),localStorage.setItem("pgr_theme_id",e)},setMode:f,toggleMode:()=>{f("light"===d?"dark":"light")}},children:e})}function l(){let e=(0,r.useContext)(i);if(void 0===e)throw Error("useTheme must be used within a ThemeProvider");return e}e.s(["ThemeProvider",()=>n,"useTheme",()=>l],95766)},26840,e=>{"use strict";var t=e.i(1989),r=e.i(26413),a=e.i(69124),s=e.i(76722);function o({children:e}){let{user:o,loading:i,isReady:n}=(0,s.useAuth)(),l=(0,a.usePathname)(),d=(0,a.useRouter)();if((0,r.useEffect)(()=>{if(n&&!i){if(!o){"/login"!==l&&"/register"!==l&&d.replace("/login");return}if("rejected"===o.status||"archived"===o.status){"/login"!==l&&d.replace("/login");return}if("approved"!==o.status){"/pending"!==l&&d.replace("/pending");return}if("/pending"===l||"/login"===l||"/register"===l)return void d.replace("/");if("/admin"===l||l.startsWith("/admin/")){"admin"!==o.role&&d.replace("/");return}}},[o,i,n,l,d]),!n||i)return null;if(o){if("rejected"===o.status||"archived"===o.status){if("/login"!==l)return null}else if("approved"!==o.status&&"/pending"!==l)return null}else if("/login"!==l&&"/register"!==l)return null;return(0,t.jsx)(t.Fragment,{children:e})}e.s(["NavigationGuard",()=>o])},7273,e=>{"use strict";var t=e.i(1989),r=e.i(69124),a=e.i(76722),s=e.i(26413),o=e.i(10923),i=e.i(68988);let n=o.default.env.NEXT_PUBLIC_APP_VERSION||i.default.version||"0.1.0";function l(){let{user:e,logout:o}=(0,a.useAuth)(),i=(0,r.useRouter)(),l=(0,r.usePathname)(),[d,c]=(0,s.useState)(!1),u=(0,s.useRef)(null),p=(0,s.useRef)(null),f="app-drawer",m=()=>{c(!1)};(0,s.useEffect)(()=>{if(!d)return;let e=e=>{u.current&&!u.current.contains(e.target)&&p.current&&!p.current.contains(e.target)&&m()};return document.addEventListener("mousedown",e),()=>document.removeEventListener("mousedown",e)},[d]),(0,s.useEffect)(()=>{if(!d)return;let e=e=>{"Escape"===e.key&&m()};return document.addEventListener("keydown",e),()=>document.removeEventListener("keydown",e)},[d]),(0,s.useEffect)(()=>{if(!d)return;let e=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.body.style.overflow=e}},[d]),(0,s.useEffect)(()=>{if(!d||!u.current)return;let e=u.current.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')[0];e&&e.focus()},[d]);let h=async()=>{m(),await o()},g=e=>{m(),i.push(e)};return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("button",{ref:p,onClick:()=>{c(e=>!e)},className:"rounded-theme-md p-2 transition-colors hover:bg-surface-2 relative z-50","aria-label":"תפריט","aria-expanded":d,"aria-controls":f,children:(0,t.jsx)("svg",{className:"h-6 w-6",style:{color:d?"var(--primary)":"var(--muted)"},fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:d?(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"}):(0,t.jsx)(t.Fragment,{children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4 6h16M4 12h16M4 18h16"})})})}),d&&(0,t.jsx)("div",{className:"fixed top-14 left-0 right-0 bottom-0 z-40",onClick:m,"aria-hidden":"true",style:{backgroundColor:"rgba(0, 0, 0, 0.2)",backdropFilter:"blur(4px)",WebkitBackdropFilter:"blur(4px)",animation:"fadeIn 150ms ease-out"}}),d&&(0,t.jsx)("div",{ref:u,id:f,role:"dialog","aria-modal":"true","aria-label":"תפריט אפליקציה",className:"fixed right-0 top-14 bottom-0 z-50 w-[80%] max-w-[360px] md:w-96 border-l border-theme bg-surface shadow-theme-lg flex flex-col",style:{animation:"slideInRight 200ms ease-out"},children:(0,t.jsxs)("div",{className:"py-2 flex-1 overflow-y-auto pb-16",children:[(0,t.jsx)("button",{onClick:()=>g("/"),className:`w-full rounded-theme-md px-4 py-3 text-right text-sm font-medium transition-colors ${"/"===l?"bg-primary text-primary-contrast":"btn-outline"}`,style:"/"===l?void 0:{color:"var(--text)"},children:"פתח שער"}),(0,t.jsx)("div",{className:"h-[1px] my-3 mx-4",style:{backgroundColor:"var(--border-strong)"}}),(0,t.jsx)("button",{onClick:()=>g("/me"),className:`w-full rounded-theme-md px-4 py-3 text-right text-sm font-medium transition-colors ${"/me"===l?"bg-primary text-primary-contrast":"btn-outline"}`,style:"/me"===l?void 0:{color:"var(--text)"},children:"אזור אישי"}),e?.role==="admin"&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"h-[1px] my-2 mx-4",style:{backgroundColor:"var(--border)"}}),(0,t.jsx)("button",{onClick:()=>g("/admin"),className:`w-full rounded-theme-md px-4 py-3 text-right text-sm font-medium transition-colors ${"/admin"===l?"bg-primary text-primary-contrast":"btn-outline"}`,style:"/admin"===l?void 0:{color:"var(--text)"},children:"ניהול"})]}),(0,t.jsx)("div",{className:"h-[1px] my-3 mx-4",style:{backgroundColor:"var(--border-strong)"}}),(0,t.jsx)("button",{onClick:h,className:"btn-outline w-full rounded-theme-md px-4 py-3 text-right text-sm font-medium",style:{color:"var(--danger)"},children:"התנתק"}),(0,t.jsx)("div",{className:"absolute bottom-0 left-0 right-0 px-4 py-3 border-t border-theme bg-surface-2",children:(0,t.jsxs)("div",{className:"text-xs text-muted text-center",children:["גרסה ",n]})})]})})]})}var d=e.i(95766),c=e.i(30533);function u(){let{themeId:e,mode:r,setTheme:a,toggleMode:o}=(0,d.useTheme)(),[i,n]=(0,s.useState)(!1),l=(0,s.useRef)(null),u=(0,s.useRef)(null),p="theme-popover",f=()=>{n(!1)};return(0,s.useEffect)(()=>{if(!i)return;let e=e=>{l.current&&!l.current.contains(e.target)&&u.current&&!u.current.contains(e.target)&&f()};return document.addEventListener("mousedown",e),()=>document.removeEventListener("mousedown",e)},[i]),(0,s.useEffect)(()=>{if(!i)return;let e=e=>{"Escape"===e.key&&f()};return document.addEventListener("keydown",e),()=>document.removeEventListener("keydown",e)},[i]),(0,s.useEffect)(()=>{if(!i)return;let e=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.body.style.overflow=e}},[i]),(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("button",{ref:u,onClick:()=>{n(e=>!e)},className:"rounded-theme-md p-2 transition-colors hover:bg-surface-2 relative z-50","aria-label":"הגדרות עיצוב","aria-expanded":i,"aria-controls":p,onFocus:e=>{e.target!==document.activeElement||e.target.matches(":focus-visible")||e.target.blur()},children:(0,t.jsx)("svg",{className:"h-6 w-6",style:{color:i?"var(--primary)":"var(--muted)"},fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:i?(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"}),(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 12a3 3 0 11-6 0 3 3 0 016 0z"})]})})}),i&&(0,t.jsx)("div",{className:"fixed top-14 left-0 right-0 bottom-0 z-40",onClick:f,"aria-hidden":"true",style:{backgroundColor:"rgba(0, 0, 0, 0.2)",backdropFilter:"blur(4px)",WebkitBackdropFilter:"blur(4px)",animation:"fadeIn 150ms ease-out"}}),i&&(0,t.jsx)("div",{ref:l,id:p,role:"dialog","aria-modal":"true","aria-label":"בחירת עיצוב",className:"fixed left-0 top-14 bottom-0 z-50 w-[80%] max-w-[360px] md:w-96 overflow-y-auto border-r border-theme bg-surface shadow-theme-lg",style:{animation:"slideInLeft 200ms ease-out"},children:(0,t.jsxs)("div",{className:"py-2",children:[(0,t.jsxs)("div",{className:"px-4 py-2",children:[(0,t.jsx)("div",{className:"mb-2 text-xs font-medium text-muted",children:"עיצוב"}),(0,t.jsx)("div",{className:"flex flex-col gap-2",children:Object.keys(c.THEMES).map(r=>{let s=c.THEMES[r],o=e===r;return(0,t.jsx)("button",{onClick:o?void 0:()=>{a(r),f()},disabled:o,className:`rounded-theme-sm px-3 py-2 text-xs font-medium transition-colors text-right ${o?"btn-primary bg-primary text-primary-contrast nav-item-active":"btn-outline bg-surface-2 text-muted nav-item-inactive"}`,children:s.labelHe},r)})})]}),(0,t.jsx)("div",{className:"h-[1px] my-3 mx-4",style:{backgroundColor:"var(--border-strong)"}}),(0,t.jsx)("button",{onClick:()=>{o(),f()},className:"btn-outline w-full rounded-theme-md px-4 py-3 text-right text-sm font-medium",style:{color:"var(--text)"},children:(0,t.jsxs)("span",{className:"flex items-center justify-between",children:[(0,t.jsxs)("span",{children:["מצב ","light"===r?"כהה":"בהיר"]}),(0,t.jsx)("span",{children:"light"===r?"🌙":"☀️"})]})})]})})]})}function p({title:e}){let a=(0,r.usePathname)(),s=e||function(e){switch(e){case"/":return"מצפה 6-8 · פתח שער";case"/admin":return"מצפה 6-8 · ניהול";case"/me":return"מצפה 6-8 · אזור אישי";default:return"מצפה 6-8"}}(a);return(0,t.jsx)("header",{className:"fixed top-0 left-0 right-0 z-40 border-b border-theme bg-surface shadow-theme-sm",style:{height:"56px"},children:(0,t.jsxs)("div",{className:"mx-auto flex h-14 max-w-7xl items-center justify-between",children:[(0,t.jsx)("div",{className:"flex-shrink-0",style:{paddingRight:"6px"},children:(0,t.jsx)(l,{})}),(0,t.jsx)("h1",{className:"flex-1 truncate text-center text-lg font-semibold whitespace-nowrap px-4",style:{color:"var(--text)"},children:s}),(0,t.jsx)("div",{className:"flex-shrink-0",style:{paddingLeft:"6px"},children:(0,t.jsx)(u,{})})]})})}function f(){let e=(0,r.usePathname)(),{user:s,loading:o,isReady:i}=(0,a.useAuth)();return"/login"!==e&&"/register"!==e&&i&&!o&&s?(0,t.jsx)(p,{}):null}e.s(["AppTopBarWrapper",()=>f],7273)}]);