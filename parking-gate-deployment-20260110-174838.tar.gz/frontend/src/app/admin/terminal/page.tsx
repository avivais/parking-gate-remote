"use client";

import AdminPageContent from "../AdminPageContent";

export default function AdminTerminalPage() {
    return <AdminPageContent defaultTab="terminal" />;
}
