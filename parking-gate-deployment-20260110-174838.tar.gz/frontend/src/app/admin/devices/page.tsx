"use client";

import AdminPageContent from "../AdminPageContent";

export default function AdminDevicesPage() {
    return <AdminPageContent defaultTab="devices" />;
}
