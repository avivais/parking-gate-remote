"use client";

import AdminPageContent from "../AdminPageContent";

export default function AdminLogsPage() {
    return <AdminPageContent defaultTab="logs" />;
}
