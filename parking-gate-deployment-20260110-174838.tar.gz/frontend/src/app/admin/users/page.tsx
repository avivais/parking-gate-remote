"use client";

import AdminPageContent from "../AdminPageContent";

export default function AdminUsersPage() {
    return <AdminPageContent defaultTab="users" />;
}
